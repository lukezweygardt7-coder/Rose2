@echo off
setlocal
 echo Rose Companion - Forge 1.12.2 build
 echo Requires a Java 8 JDK and Gradle 4.10.3.
 java -version
 if errorlevel 1 goto failed
 gradle --version
 if errorlevel 1 goto failed
 gradle setupCIWorkspace build --no-daemon --stacktrace
 if errorlevel 1 goto failed
 echo.
 echo Build complete: build\libs\RoseCompanion-1.0.0.jar
 pause
 goto end
:failed
 echo.
 echo Build failed. Check that Java 8 and Gradle 4.10.3 are installed and selected.
 pause
:end
endlocal
