#!/usr/bin/env sh
set -eu
printf '%s\n' 'Rose Companion - Forge 1.12.2 build'
printf '%s\n' 'Requires a Java 8 JDK and Gradle 4.10.3.'
java -version
gradle --version
gradle setupCIWorkspace build --no-daemon --stacktrace
printf '%s\n' 'Build output: build/libs/RoseCompanion-1.0.0.jar'
