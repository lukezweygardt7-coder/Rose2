package com.rosecompanion.network;

import com.rosecompanion.entity.EntityRoseDog;
import com.rosecompanion.world.RoseActions;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class RoseActionMessage implements IMessage {
    private String action = "answer";
    private String item = "";
    private String response = "Woof!";

    public RoseActionMessage() {
    }

    public RoseActionMessage(String action, String item, String response) {
        this.action = clean(action, 32);
        this.item = clean(item, 64);
        this.response = clean(response, 220);
    }

    @Override
    public void toBytes(ByteBuf buffer) {
        ByteBufUtils.writeUTF8String(buffer, action);
        ByteBufUtils.writeUTF8String(buffer, item);
        ByteBufUtils.writeUTF8String(buffer, response);
    }

    @Override
    public void fromBytes(ByteBuf buffer) {
        action = clean(ByteBufUtils.readUTF8String(buffer), 32);
        item = clean(ByteBufUtils.readUTF8String(buffer), 64);
        response = clean(ByteBufUtils.readUTF8String(buffer), 220);
    }

    private static String clean(String value, int max) {
        if (value == null) return "";
        String clean = value.replace('\n', ' ').replace('\r', ' ').trim();
        return clean.length() > max ? clean.substring(0, max) : clean;
    }

    public static class Handler implements IMessageHandler<RoseActionMessage, IMessage> {
        @Override
        public IMessage onMessage(final RoseActionMessage message, final MessageContext context) {
            final EntityPlayerMP player = context.getServerHandler().player;
            FMLCommonHandler.instance().getMinecraftServerInstance().addScheduledTask(() ->
                    RoseActions.execute(player, message.action, message.item, message.response));
            return null;
        }
    }
}
