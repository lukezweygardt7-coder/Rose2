package com.rosecompanion.client;

import com.rosecompanion.RoseCompanion;
import com.rosecompanion.entity.EntityRoseDog;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderRoseDog extends RenderLiving<EntityRoseDog> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(RoseCompanion.MODID, "textures/entity/rose.png");

    public RenderRoseDog(RenderManager manager) {
        super(manager, new ModelRoseDog(), 0.45F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityRoseDog entity) {
        return TEXTURE;
    }
}
