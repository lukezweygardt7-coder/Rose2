package com.rosecompanion.client;

import com.rosecompanion.entity.EntityRoseDog;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class ModelRoseDog extends ModelBase {
    private final ModelRenderer body;
    private final ModelRenderer head;
    private final ModelRenderer muzzle;
    private final ModelRenderer earLeft;
    private final ModelRenderer earRight;
    private final ModelRenderer tail;
    private final ModelRenderer collar;
    private final ModelRenderer frontLeft;
    private final ModelRenderer frontRight;
    private final ModelRenderer backLeft;
    private final ModelRenderer backRight;

    public ModelRoseDog() {
        textureWidth = 64;
        textureHeight = 64;

        body = new ModelRenderer(this, 0, 0);
        body.setRotationPoint(0.0F, 13.0F, 0.0F);
        body.addBox(-4.0F, -3.0F, -6.0F, 8, 6, 12, 0.0F);

        head = new ModelRenderer(this, 0, 20);
        head.setRotationPoint(0.0F, 8.0F, -5.0F);
        head.addBox(-4.0F, -3.0F, -4.0F, 8, 7, 7, 0.0F);

        muzzle = new ModelRenderer(this, 30, 20);
        muzzle.setRotationPoint(0.0F, 0.0F, -3.5F);
        muzzle.addBox(-2.0F, -0.6F, -3.0F, 4, 3, 3, 0.0F);
        head.addChild(muzzle);

        earLeft = new ModelRenderer(this, 30, 27);
        earLeft.setRotationPoint(-2.8F, -2.6F, -1.5F);
        earLeft.addBox(-1.0F, -2.7F, -0.6F, 2, 3, 2, 0.0F);
        head.addChild(earLeft);

        earRight = new ModelRenderer(this, 38, 27);
        earRight.setRotationPoint(2.8F, -2.6F, -1.5F);
        earRight.addBox(-1.0F, -2.7F, -0.6F, 2, 3, 2, 0.0F);
        head.addChild(earRight);

        collar = new ModelRenderer(this, 48, 40);
        collar.setRotationPoint(0.0F, 10.3F, -4.4F);
        collar.addBox(-4.1F, -0.6F, -1.2F, 8, 1, 2, 0.05F);

        tail = new ModelRenderer(this, 16, 40);
        tail.setRotationPoint(0.0F, 12.0F, 5.5F);
        tail.addBox(-1.0F, -4.0F, 0.0F, 2, 5, 2, 0.0F);

        frontLeft = leg(0, 40, -2.6F, 15.0F, -3.8F);
        frontRight = leg(12, 40, 2.6F, 15.0F, -3.8F);
        backLeft = leg(24, 40, -2.6F, 15.0F, 3.8F);
        backRight = leg(36, 40, 2.6F, 15.0F, 3.8F);
    }

    private ModelRenderer leg(int textureX, int textureY, float x, float y, float z) {
        ModelRenderer leg = new ModelRenderer(this, textureX, textureY);
        leg.setRotationPoint(x, y, z);
        leg.addBox(-1.5F, 0.0F, -1.5F, 3, 5, 3, 0.0F);
        return leg;
    }

    @Override
    public void setLivingAnimations(EntityLivingBase entity, float limbSwing, float limbSwingAmount, float partialTick) {
        if (!(entity instanceof EntityRoseDog)) {
            return;
        }
        EntityRoseDog rose = (EntityRoseDog) entity;
        boolean sitting = rose.isSitting();
        body.rotationPointY = sitting ? 15.0F : 13.0F;
        body.rotateAngleX = sitting ? -0.12F : 0.0F;
        frontLeft.rotationPointY = sitting ? 13.0F : 15.0F;
        frontRight.rotationPointY = sitting ? 13.0F : 15.0F;
        backLeft.rotationPointY = sitting ? 15.0F : 15.0F;
        backRight.rotationPointY = sitting ? 15.0F : 15.0F;
        backLeft.rotateAngleX = sitting ? -1.15F : 0.0F;
        backRight.rotateAngleX = sitting ? -1.15F : 0.0F;
        frontLeft.rotateAngleX = sitting ? -0.45F : 0.0F;
        frontRight.rotateAngleX = sitting ? -0.45F : 0.0F;
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
        head.rotateAngleY = netHeadYaw * 0.017453292F;
        head.rotateAngleX = headPitch * 0.017453292F;

        float walk = (float) Math.cos(limbSwing * 0.6662F) * 1.35F * limbSwingAmount;
        frontLeft.rotateAngleX += walk;
        backRight.rotateAngleX += walk;
        frontRight.rotateAngleX -= walk;
        backLeft.rotateAngleX -= walk;

        tail.rotateAngleX = 0.35F;
        tail.rotateAngleY = (float) Math.sin(ageInTicks * 0.32F) * 0.40F;
        earLeft.rotateAngleZ = -0.10F + (float) Math.sin(ageInTicks * 0.12F) * 0.04F;
        earRight.rotateAngleZ = 0.10F - (float) Math.sin(ageInTicks * 0.12F) * 0.04F;

        if (entityIn instanceof EntityRoseDog) {
            EntityRoseDog rose = (EntityRoseDog) entityIn;
            if (rose.isDigging()) {
                float dig = (float) Math.sin(ageInTicks * 1.05F) * 0.85F;
                head.rotateAngleX = 0.50F;
                frontLeft.rotateAngleX = -0.35F + dig;
                frontRight.rotateAngleX = -0.35F - dig;
                tail.rotateAngleY = (float) Math.sin(ageInTicks * 0.55F) * 0.25F;
            } else if (rose.getReaction() == 1) {
                // A happy little head nod for yes.
                head.rotateAngleX = -0.18F + (float) Math.sin(ageInTicks * 0.65F) * 0.22F;
                tail.rotateAngleY += (float) Math.sin(ageInTicks * 0.55F) * 0.18F;
            } else if (rose.getReaction() == 2) {
                // A clear side-to-side head shake for no.
                head.rotateAngleY += (float) Math.sin(ageInTicks * 0.85F) * 0.72F;
                earLeft.rotateAngleZ = -0.18F;
                earRight.rotateAngleZ = 0.18F;
            }
        }
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                       float netHeadYaw, float headPitch, float scale) {
        setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);
        body.render(scale);
        collar.render(scale);
        head.render(scale);
        tail.render(scale);
        frontLeft.render(scale);
        frontRight.render(scale);
        backLeft.render(scale);
        backRight.render(scale);
    }
}
