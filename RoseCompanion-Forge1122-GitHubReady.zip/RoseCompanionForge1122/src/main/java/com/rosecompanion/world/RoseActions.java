package com.rosecompanion.world;

import com.rosecompanion.entity.EntityRoseDog;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public final class RoseActions {
    private static final Set<String> FETCH_ALLOWLIST = new HashSet<>(Arrays.asList(
            "minecraft:diamond", "minecraft:bone", "minecraft:stick", "minecraft:iron_ingot",
            "minecraft:gold_ingot", "minecraft:emerald", "minecraft:coal", "minecraft:apple",
            "minecraft:bread", "minecraft:torch", "minecraft:string", "minecraft:feather",
            "minecraft:spider_eye", "minecraft:rotten_flesh", "minecraft:oak_planks"
    ));

    private RoseActions() {
    }

    public static void execute(EntityPlayerMP player, String action, String itemId, String response) {
        if (player == null || player.world == null) return;
        EntityRoseDog rose = EntityRoseDog.findOwnedDog(player.world, player, 64.0D);
        if (rose == null) {
            tell(player, "I can't see you! Use the Rose Whistle to call me.");
            return;
        }

        if ("answer".equals(action) || "reject".equals(action)) {
            String normalized = response == null ? "" : response.trim().toLowerCase();
            if ("reject".equals(action) || normalized.startsWith("no")) {
                rose.triggerReaction(false);
            } else if (normalized.startsWith("yes")) {
                rose.triggerReaction(true);
            }
            tell(player, response);
        } else if ("follow".equals(action)) {
            rose.setSitting(false);
            rose.getNavigator().clearPath();
            tell(player, response);
        } else if ("sit".equals(action)) {
            rose.cancelFetch();
            rose.setSitting(true);
            rose.getNavigator().clearPath();
            tell(player, response);
        } else if ("dig_item".equals(action)) {
            if (!FETCH_ALLOWLIST.contains(itemId)) {
                tell(player, "I don't know how to fetch that item yet.");
                return;
            }
            Item item = Item.getByNameOrId(itemId);
            if (item == null) {
                tell(player, "I couldn't find that item in this version.");
                return;
            }
            BlockPos target = findSoftPatch(player.world, player);
            if (target == null) {
                tell(player, "I can't find a soft patch of dirt nearby.");
                return;
            }
            rose.setFetchRequest(target, new ItemStack(item));
            tell(player, response);
        } else if ("build_house".equals(action)) {
            boolean built = RoseHouseBuilder.buildStarterHouse(player.world, player);
            tell(player, built ? response : "No, I need a flatter, clearer place to build a small house.");
        } else {
            tell(player, response);
        }
    }

    private static BlockPos findSoftPatch(World world, EntityPlayerMP player) {
        float yaw = player.rotationYaw * 0.017453292F;
        int forwardX = Math.round(-MathHelper.sin(yaw));
        int forwardZ = Math.round(MathHelper.cos(yaw));
        int sideX = -forwardZ;
        int sideZ = forwardX;

        for (int distance = 2; distance <= 5; distance++) {
            for (int side = -2; side <= 2; side++) {
                int x = MathHelper.floor(player.posX + forwardX * distance + sideX * side);
                int z = MathHelper.floor(player.posZ + forwardZ * distance + sideZ * side);
                BlockPos ground = world.getHeight(new BlockPos(x, 0, z)).down();
                if (isSoftGround(world, ground) && world.isAirBlock(ground.up())) {
                    return ground;
                }
            }
        }

        BlockPos belowPlayer = world.getHeight(new BlockPos(player.getPosition().getX(), 0,
                player.getPosition().getZ())).down();
        return isSoftGround(world, belowPlayer) && world.isAirBlock(belowPlayer.up()) ? belowPlayer : null;
    }

    private static boolean isSoftGround(World world, BlockPos pos) {
        if (!world.isBlockLoaded(pos)) return false;
        Block block = world.getBlockState(pos).getBlock();
        return block == Blocks.DIRT || block == Blocks.GRASS
                || block == Blocks.SAND || block == Blocks.GRAVEL;
    }

    private static void tell(EntityPlayerMP player, String text) {
        String safe = text == null ? "Woof!" : text.replace('\n', ' ').replace('\r', ' ').trim();
        if (safe.length() > 220) safe = safe.substring(0, 217) + "...";
        player.sendMessage(new TextComponentString("§dRose: §f" + safe));
    }
}
