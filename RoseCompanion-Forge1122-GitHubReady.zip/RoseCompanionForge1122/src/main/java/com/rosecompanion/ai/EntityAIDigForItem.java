package com.rosecompanion.ai;

import com.rosecompanion.entity.EntityRoseDog;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.util.math.BlockPos;

public class EntityAIDigForItem extends EntityAIBase {
    private final EntityRoseDog rose;

    public EntityAIDigForItem(EntityRoseDog rose) {
        this.rose = rose;
        setMutexBits(3);
    }

    @Override
    public boolean shouldExecute() {
        return rose.getFetchTarget() != null && !rose.isSitting();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return rose.getFetchTarget() != null && !rose.isSitting();
    }

    @Override
    public void updateTask() {
        BlockPos target = rose.getFetchTarget();
        if (target == null) {
            rose.setDigging(false);
            return;
        }

        double x = target.getX() + 0.5D;
        double y = target.getY() + 1.0D;
        double z = target.getZ() + 0.5D;
        double distanceSq = rose.getDistanceSq(x, y, z);

        if (distanceSq > 3.5D) {
            rose.setDigging(false);
            rose.getNavigator().tryMoveToXYZ(x, y, z, 1.08D);
        } else {
            rose.getNavigator().clearPath();
            if (!rose.isDigging()) {
                rose.beginDigging();
            } else {
                rose.advanceDigging();
            }
        }
    }

    @Override
    public void resetTask() {
        if (rose.getFetchTarget() != null) {
            rose.cancelFetch();
        }
    }
}
