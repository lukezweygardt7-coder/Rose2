package com.rosecompanion.entity;

import com.rosecompanion.ai.EntityAIDigForItem;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIFollowOwner;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAISit;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

public class EntityRoseDog extends EntityTameable {
    private static final DataParameter<Boolean> DIGGING =
            EntityDataManager.createKey(EntityRoseDog.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Integer> REACTION =
            EntityDataManager.createKey(EntityRoseDog.class, DataSerializers.VARINT);

    private BlockPos fetchTarget;
    private ItemStack fetchStack = ItemStack.EMPTY;
    private int digTicks;
    private int reactionTicks;

    public EntityRoseDog(World worldIn) {
        super(worldIn);
        setSize(0.78F, 0.82F);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        dataManager.register(DIGGING, Boolean.FALSE);
        dataManager.register(REACTION, 0);
    }

    @Override
    protected void initEntityAI() {
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIPanic(this, 1.25D));
        tasks.addTask(2, new EntityAISit(this));
        tasks.addTask(3, new EntityAIDigForItem(this));
        tasks.addTask(4, new EntityAIFollowOwner(this, 1.12D, 5.0F, 2.0F));
        tasks.addTask(6, new EntityAIWander(this, 0.90D));
        tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(8, new EntityAILookIdle(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(30.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.31D);
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.getItem() == Items.BONE;
    }

    @Override
    protected net.minecraft.util.SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_WOLF_AMBIENT;
    }

    @Override
    protected net.minecraft.util.SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_WOLF_HURT;
    }

    @Override
    protected net.minecraft.util.SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_WOLF_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 0.65F;
    }

    @Override
    public boolean canDespawn() {
        return false;
    }

    public boolean isDigging() {
        return dataManager.get(DIGGING);
    }

    public void setDigging(boolean value) {
        dataManager.set(DIGGING, value);
    }

    /** 0 = neutral, 1 = yes/nod, 2 = no/shake. */
    public int getReaction() {
        return dataManager.get(REACTION);
    }

    public void triggerReaction(boolean yes) {
        if (world.isRemote) return;
        dataManager.set(REACTION, yes ? 1 : 2);
        reactionTicks = 34;
    }

    public BlockPos getFetchTarget() {
        return fetchTarget;
    }

    public void setFetchRequest(BlockPos target, ItemStack requested) {
        if (target == null || requested == null || requested.isEmpty() || world.isRemote) {
            return;
        }
        fetchTarget = target;
        fetchStack = requested.copy();
        digTicks = 0;
        setSitting(false);
        setDigging(false);
        getNavigator().clearPath();
    }

    public void beginDigging() {
        digTicks = 0;
        setDigging(true);
        getNavigator().clearPath();
    }

    public void advanceDigging() {
        if (!world.isRemote && fetchTarget != null) {
            digTicks++;
            if (digTicks >= 65) {
                completeFetch();
            }
        }
    }

    public void cancelFetch() {
        fetchTarget = null;
        fetchStack = ItemStack.EMPTY;
        digTicks = 0;
        setDigging(false);
    }

    private void completeFetch() {
        if (fetchTarget == null || fetchStack.isEmpty() || world.isRemote) {
            cancelFetch();
            return;
        }

        if (world.isBlockLoaded(fetchTarget)) {
            Block block = world.getBlockState(fetchTarget).getBlock();
            boolean softGround = block == Blocks.DIRT || block == Blocks.GRASS
                    || block == Blocks.SAND || block == Blocks.GRAVEL;
            if (!softGround) {
                cancelFetch();
                return;
            }
            world.setBlockToAir(fetchTarget);
            ItemStack result = fetchStack.copy();
            EntityItem item = new EntityItem(world,
                    fetchTarget.getX() + 0.5D,
                    fetchTarget.getY() + 0.12D,
                    fetchTarget.getZ() + 0.5D,
                    result);
            item.setDefaultPickupDelay();
            item.motionY = 0.12D;
            world.spawnEntity(item);
        }
        cancelFetch();
    }

    public static EntityRoseDog findOwnedDog(World world, EntityPlayer player, double radius) {
        List<EntityRoseDog> dogs = world.getEntitiesWithinAABB(EntityRoseDog.class,
                player.getEntityBoundingBox().grow(radius));
        for (EntityRoseDog dog : dogs) {
            UUID owner = dog.getOwnerId();
            if (owner != null && owner.equals(player.getUniqueID())) {
                return dog;
            }
        }
        return null;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (isSitting() && isDigging()) {
            setDigging(false);
        }
        if (!world.isRemote && reactionTicks > 0) {
            reactionTicks--;
            if (reactionTicks == 0) dataManager.set(REACTION, 0);
        }
    }
}
