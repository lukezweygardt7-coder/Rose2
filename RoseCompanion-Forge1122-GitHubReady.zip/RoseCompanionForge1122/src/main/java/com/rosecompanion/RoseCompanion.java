package com.rosecompanion;

import com.rosecompanion.ai.RoseConfig;
import com.rosecompanion.entity.EntityRoseDog;
import com.rosecompanion.network.RoseNetwork;
import com.rosecompanion.proxy.CommonProxy;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;

@Mod(modid = RoseCompanion.MODID, name = RoseCompanion.NAME, version = RoseCompanion.VERSION,
        acceptedMinecraftVersions = "[1.12.2]")
public class RoseCompanion {
    public static final String MODID = "rosecompanion";
    public static final String NAME = "Rose - Smart Companion Dog";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static RoseCompanion INSTANCE;

    @SidedProxy(clientSide = "com.rosecompanion.proxy.ClientProxy",
            serverSide = "com.rosecompanion.proxy.CommonProxy")
    public static CommonProxy PROXY;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        RoseConfig.load(event.getModConfigurationDirectory());
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "rose_dog"),
                EntityRoseDog.class, "Rose", 1, this, 64, 3, true, 0xA86D48, 0xF2C9D8);
        RoseNetwork.init();
        PROXY.preInit();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        PROXY.init();
    }
}
