package com.rosecompanion.proxy;

public class CommonProxy {
    public void preInit() { }
    public void init() { }
}
