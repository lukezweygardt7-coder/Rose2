# Rose — Smart Companion Dog (Minecraft Forge 1.12.2)

Rose is a companion dog for **Minecraft Java Edition 1.12.2**. This repository contains the Forge mod source, a custom dog model and texture, a reusable whistle, V-key push-to-talk recording, AssemblyAI transcription, Gemini command interpretation, and a restricted set of server-side actions.

## What's included

- **Rose companion:** use the Rose Whistle to summon and bond Rose to the player. She remains in the world and follows her owner using Minecraft's built-in tameable-entity pathfinding.
- **Dog model and animations:** tail wagging, ear movement, head tracking, walking/running legs, sitting, paw-digging, and yes/no head gestures.
- **V-key push-to-talk:** press **V** to start microphone recording and press **V** again to stop and submit the completed recording.
- **Voice pipeline:** AssemblyAI transcribes the WAV recording; Gemini interprets the transcript and a small nearby-world snapshot.
- **Rose's actions:** answer/reject questions, sit, follow, fetch a supported item by digging one nearby soft-ground block, or build a compact 5 x 5 starter house on a flat soft-surface patch.
- **Bounded world sensor:** only a small loaded area around the player and a few nearby entity names are scanned. Rose does not see the whole world or unloaded/distant chunks.
- **Action safety:** Gemini can only select from fixed action names. The mod validates item IDs and never executes AI-generated commands, scripts, Java, or arbitrary code.
- **Performance:** microphone recording and HTTP requests run on background threads. Small world snapshots are collected locally before the network call.

## Honest feature limits

Rose is an AI-assisted game companion, not an unrestricted Minecraft-playing agent. This first version does not independently mine long distances, locate real underground diamond veins, craft multi-step recipes, fight mobs on command, manage inventory, or build large/detailed mansions. The fetch action is intentionally magical: Rose animates digging, removes one nearby dirt/grass/sand/gravel block, and drops the requested allowlisted item. It does not verify that the item was naturally underground. The house action places a compact wooden starter house only when its footprint is flat, clear, and covered by soft ground.

The AI receives the spoken transcript and a compact local Minecraft snapshot. Voice recordings are uploaded to AssemblyAI, and the transcript plus nearby-world snapshot are sent to Gemini. Check both providers' current privacy terms and usage limits before enabling voice chat. AssemblyAI's free account is a limited trial-credit tier, not unlimited free transcription; Gemini has a free tier with rate limits and its own data-use terms.

## Target toolchain

- Minecraft **1.12.2**
- Forge **14.23.5.2864**
- **Java 8 JDK**
- **Gradle 4.10.3**

Forge 1.12.2 is an older toolchain. Use Java 8 for building; Java 17/21 is not suitable for this legacy ForgeGradle project. The official Forge downloads page lists 14.23.5.2864 and its MDK. See [Forge 1.12.2 downloads](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.12.2.html).

## Build locally

On Windows, run `BUILD_WINDOWS.bat` from the project root. On Linux/macOS, run:

```sh
chmod +x BUILD_LINUX.sh
./BUILD_LINUX.sh
```

The scripts expect Java 8 and Gradle 4.10.3 to be installed and selected. The resulting mod JAR should appear in `build/libs/`.

## Build with GitHub Actions (recommended for Android users)

This repository includes `.github/workflows/build.yml`.

1. Create a GitHub repository and upload the **contents of this project folder** to its root. Keep the `.github/workflows/build.yml` path intact.
2. Open the repository's **Actions** tab and enable Actions if GitHub asks.
3. Push/commit the files (or run **Build Rose Companion** from the Actions tab using **Run workflow**).
4. Open the successful workflow run and download the `RoseCompanion-Forge-1.12.2` artifact.
5. Extract the artifact ZIP and copy the `.jar` into the Forge 1.12.2 `mods` folder.

The workflow uses Temurin Java 8 and Gradle 4.10.3, runs the ForgeGradle CI workspace setup and build, verifies the expected classes/resources are present in the JAR, and uploads the result. **The workflow has not been executed from this chat**, so the first GitHub run is the actual build verification. If it fails, share the complete Actions log (not API keys) so the exact failing step can be corrected.

## Install and summon Rose

1. Install Minecraft Forge 1.12.2 - 14.23.5.2864.
2. Build the project and copy `RoseCompanion-1.0.0.jar` into the Minecraft `mods` folder.
3. Launch a Forge 1.12.2 world.
4. Obtain the reusable whistle with:

   ```text
   /give @p rosecompanion:rose_whistle
   ```

5. Right-click with the Rose Whistle. Rose will appear, bond to you, and follow you. Reusing the whistle calls your nearby Rose rather than creating duplicates.

The whistle is also available from the Miscellaneous creative inventory tab.

## Configure voice AI

1. Launch Minecraft once with the mod installed. It creates:

   ```text
   .minecraft/config/rosecompanion.properties
   ```

2. Close Minecraft and open that file with a text editor. Fill in both values:

   ```properties
   assemblyai_api_key=YOUR_ASSEMBLYAI_KEY
   assemblyai_speech_model=universal-3-5-pro
   gemini_api_key=YOUR_GEMINI_KEY
   gemini_model=gemini-3.8-flash
   voice_max_seconds=90
   ```

3. Save the file and restart Minecraft.
4. With Rose present, press **V**, speak, and press **V** again to submit.

The AssemblyAI API key must be from the same AssemblyAI project for upload and transcription. The Gemini key is sent in the `x-goog-api-key` request header. Neither key is embedded in the mod JAR or source repository.

**Security:** the local properties file stores keys as plain text. Do not post it publicly, include it in a mod release, screenshot it, or commit it to GitHub. `.gitignore` excludes the live config file. The mod does not need either key to load; only voice chat needs both.

## Android / Mojo Launcher note

The GitHub Actions artifact route lets you build without Gradle on the tablet. Copy the resulting JAR into the Forge profile's `mods` directory. The voice recorder uses Java Sound (`javax.sound.sampled`); some Android Java runtimes/launchers do not expose Java Sound microphone capture. If Mojo does not provide a compatible microphone input, Rose can still load and follow the player, but V-key voice recording will not work on that runtime until a launcher-compatible capture backend is added.

## Example spoken requests

- “Rose, I love you.”
- “Can you find me a diamond?”
- “Dig up a bone for me.”
- “Get me a stick.”
- “Build me a simple starter house.”
- “Please sit.”
- “Come follow me.”
- “Build an 80-floor mansion.” (Rose should politely reject an unreasonable request.)

## Multiplayer

Install the mod on both the client and Forge server. Microphone capture and AI requests run on the client; only a small validated action packet is sent to the server. API keys belong in the local client config, not a shared server config. Server owners should review any mod before using it on a public server.

## Build toolchain note

This project uses ForgeGradle 5.1.77 with Gradle 7.6.4 and a Java 8 JDK.
Forge 1.12.2 build 14.23.5.2864 publishes the UserDev 3 artifact; the older
ForgeGradle 2.3 configuration requests a legacy `-userdev.jar` artifact and
cannot resolve this Forge release. Build with `gradle clean build` (not the
old `setupCIWorkspace` task).
